//
//  FFI_iBeacons.h
//  KLBeacon
//
//  Created by Amba on 25/02/14.
//  Copyright (c) 2014 Konylabs. All rights reserved.
//

#import "KLBeaconManager.h"
#import "KLBeaconRegion.h"
#import "KLBeacon.h"
#import "KLPeripheralManager.h"

#define FFI_IBEACONS_SDK_VERSION @"1.0.0"